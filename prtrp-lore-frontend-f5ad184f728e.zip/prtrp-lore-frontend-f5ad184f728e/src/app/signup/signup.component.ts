import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, ValidatorFn } from '@angular/forms';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  registerForm: FormGroup;
  success: boolean = false;
  emailExists: boolean = false;
  error: boolean = false;

  constructor(private authService: AuthService) {}

  matchPasswordValidator(): ValidatorFn {
    return (registerForm: FormControl): { [key: string]: any } => {
      const password = registerForm.value.password;
      const confirm_password = registerForm.value.confirm_password;
      let isValid = true;
      if (password !== confirm_password) {
        isValid = false;
      }
      return !isValid ? { matchPasswordValidator: { value: 'Passwords are not matching' } } : null;
    };
  }

  register() {
    const newUser = this.registerForm.value;
    this.error = this.success = this.emailExists = false;
    console.log('newUser', newUser);

    this.authService.register(newUser).then(results => {
      console.log('results', results);
      if (results && results.error) {
        switch (results.error) {
          case 'EMAIL_EXISTS':
            this.emailExists = true;
            break;

          default:
            this.error = true;
        }
      } else {
        this.success = true;
        this.registerForm.reset();
      }
    });
  }

  ngOnInit() {
    this.registerForm = new FormGroup(
      {
        name: new FormControl(null, [Validators.required, Validators.minLength(3)]),
        email: new FormControl(null, [Validators.required, Validators.email]),
        mobile: new FormControl(null),
        password: new FormControl(null, [Validators.required, Validators.minLength(8)]),
        confirm_password: new FormControl(null, [Validators.required, Validators.minLength(8)])
      },
      this.matchPasswordValidator()
    );
  }

  get name() {
    return this.registerForm.get('name');
  }

  get email() {
    return this.registerForm.get('email');
  }

  get mobile() {
    return this.registerForm.get('mobile');
  }

  get password() {
    return this.registerForm.get('password');
  }

  get confirm_password() {
    return this.registerForm.get('confirm_password');
  }
}
