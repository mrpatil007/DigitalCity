import { Component, OnInit } from '@angular/core';
import { trigger, state, style, animate, transition, keyframes, group } from '@angular/animations';

import { AuthService } from '../auth.service';
import { CompareService } from '../compare.service';
import { FlashMessagesService } from 'ngx-flash-messages';

const flashMessageTimeout = 1500;

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css'],
  animations: [
    trigger('compareVisible', [
      state(
        'false',
        style({
          backgroundColor: '#eee',
          transform: 'scale(0)'
        })
      ),
      state(
        'true',
        style({
          backgroundColor: '#cfd8dc',
          transform: 'scale(1)'
        })
      ),
      transition('false => true', [
        animate(
          300,
          keyframes([
            style({ opacity: 0, transform: 'translateX(-100%)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(15px)', offset: 0.3 }),
            style({ opacity: 1, transform: 'translateX(0)', offset: 1.0 })
          ])
        )
      ]),
      transition('true => false', [
        animate(
          300,
          keyframes([
            style({ opacity: 1, transform: 'translateX(0)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(-15px)', offset: 0.7 }),
            style({ opacity: 0, transform: 'translateX(100%)', offset: 1.0 })
          ])
        )
      ])
    ])
  ]
})
export class WishlistComponent implements OnInit {
  myWishlist: Array<any> = [];
  compareIds: Array<any> = [];
  compareItems: number = 0;

  constructor(private authService: AuthService, private compareService: CompareService, private flashMessagesService: FlashMessagesService) {}

  addToCompare(id: number) {
    this.flashMessagesService.show('Course Added to Compare', {
      classes: ['alert', 'alert-success'],
      timeout: flashMessageTimeout
    });

    if (this.compareService.addToCompare(id)) {
      this.compareIds.push(id);
      this.compareItems = this.compareIds.length;
    } else {
      if (this.compareItems >= 3) {
        alert('Already added 3 courses to compare');
      }
    }
  }

  removeFromCompare(id: string) {
    this.flashMessagesService.show('Course Removed from Compare', {
      classes: ['alert', 'alert-danger'],
      timeout: flashMessageTimeout
    });

    this.compareService.removeFromCompare(id);
    this.compareIds = this.compareService.getCompareCourses();
    this.compareItems = this.compareIds.length;
  }

  removeFromWishlist(courseId: number) {
    this.flashMessagesService.show('Course Removed from Wishlist', {
      classes: ['alert', 'alert-danger'],
      timeout: flashMessageTimeout
    });

    this.authService.removeFromWishlist(courseId).then(results => {
      this.myWishlist = this.myWishlist.filter(x => x.id != courseId);
    });
  }

  ngOnInit() {
    this.compareIds = this.compareService.getCompareCourses();
    this.compareItems = this.compareIds.length;
    this.authService.myWishlist().subscribe(results => {
      this.myWishlist = results.courses;
    });
  }
}
