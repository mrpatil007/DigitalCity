import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

import * as $ from 'jquery';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit, OnDestroy {
  loginForm: FormGroup;
  activeTab: boolean = true;
  isLoggedIn: boolean = false;
  userObject: Object = {
    id: null,
    name: null,
    email: null,
    token: null
  };
  @Output() onLogin = new EventEmitter();
  @Output() onLogout = new EventEmitter();

  constructor(private authService: AuthService) {}

  switchTab() {
    this.activeTab = !this.activeTab;
  }

  login() {
    const email = this.loginForm.get('email').value;
    const password = this.loginForm.get('password').value;

    this.authService.login(email, password).subscribe(user => {
      if (user.error) {
        this.loginForm.get('email').setErrors({ incorrect: true });
      } else {
        this.isLoggedIn = true;
        this.userObject = this.authService.getUser();
        ($('.modal-backdrop') as any).hide();
        this.onLogin.emit();
      }
    });
  }

  logout() {
    this.authService.logOut();
    this.isLoggedIn = false;
    this.loginForm = new FormGroup({
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null, [Validators.required, Validators.minLength(8)])
    });
    this.onLogout.emit();
  }

  ngOnInit() {
    this.isLoggedIn = this.authService.isValid();
    if (this.isLoggedIn) {
      this.userObject = this.authService.getUser();
      this.loginForm = null;
    } else {
      this.loginForm = new FormGroup({
        email: new FormControl(null, [Validators.required, Validators.email]),
        password: new FormControl(null, [Validators.required, Validators.minLength(8)])
      });
    }
  }

  ngOnDestroy() {
    this.loginForm = null;
  }

  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }
}
