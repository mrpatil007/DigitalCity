import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

const MAX_COMPARE_ITEMS = 3;

@Injectable()
export class CompareService {
  private compareCookie = 'compare';
  constructor(private cookieService: CookieService) {}

  addToCompare(id: number): boolean {
    if (this.cookieService.check(this.compareCookie)) {
      const compare: string = this.cookieService.get(this.compareCookie);
      let courseIds: Array<any> = compare.split('|');
      if (courseIds.length < MAX_COMPARE_ITEMS && courseIds.indexOf(id) === -1) {
        courseIds.push(id);
        this.cookieService.delete(this.compareCookie, '/');
        this.cookieService.set(this.compareCookie, courseIds.join('|'), 0, '/');
        return true;
      } else {
        return false;
      }
    } else {
      this.cookieService.set(this.compareCookie, String(id), 0, '/');
      return true;
    }
  }

  removeFromCompare(id: string): boolean {
    if (this.cookieService.check(this.compareCookie)) {
      const compare: string = this.cookieService.get(this.compareCookie);
      let courseIds: Array<any> = compare.split('|');
      if (courseIds.indexOf(id) !== -1) {
        courseIds = courseIds.filter(courseId => courseId !== id);
        this.cookieService.delete(this.compareCookie, '/');

        if (courseIds.length) this.cookieService.set(this.compareCookie, courseIds.join('|'), 0, '/');
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  getCompareCourses(): string[] {
    if (this.cookieService.check(this.compareCookie)) {
      const courseIds = this.cookieService.get(this.compareCookie);
      return courseIds.split('|');
    } else {
      return [];
    }
  }
}
