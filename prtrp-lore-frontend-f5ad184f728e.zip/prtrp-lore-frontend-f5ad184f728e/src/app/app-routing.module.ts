import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { SearchComponent } from './search/search.component';
import { ResultsComponent } from './results/results.component';
import { CourseComponent } from './course/course.component';
import { CompareComponent } from './compare/compare.component';
import { InfoComponent } from './info/info.component';
import { WishlistComponent } from './wishlist/wishlist.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', component: HomeComponent },
  { path: 'search', component: HomeComponent },
  { path: 'results/:text', component: ResultsComponent },
  { path: 'course/:id', component: CourseComponent },
  { path: 'compare', component: CompareComponent },
  { path: 'info', component: InfoComponent },
  { path: 'wishlist', component: WishlistComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
