import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../environments/environment';
import { Router } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import { tap } from 'rxjs/operators';

import { CookieService } from 'ngx-cookie-service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class AuthService {
  private apiAuthLogin: string = environment.apiHost + '/api/auth/login';
  private apiAuthRegister: string = environment.apiHost + '/api/auth/register';
  private apiWishlist: string = environment.apiHost + '/api/wishlist';
  private apiUnwishlist: string = environment.apiHost + '/api/unwishlist';

  constructor(private http: HttpClient, private router: Router, private cookieService: CookieService) {}

  isValid(): boolean {
    return this.cookieService.check('token');
  }

  getUser() {
    const authCookie: any = this.cookieService.getAll();

    return {
      id: authCookie.id,
      name: authCookie.name,
      email: authCookie.email,
      token: authCookie.token
    };
  }

  login(email: string, password: string): Observable<any> {
    return this.http.post(this.apiAuthLogin, { email, password }, httpOptions).pipe(
      tap(user => {
        if (!user.error) {
          this.cookieService.set('id', user.id, 0, '/');
          this.cookieService.set('name', user.name, 0, '/');
          this.cookieService.set('email', user.email, 0, '/');
          this.cookieService.set('token', user.jwt, 0, '/');
        }
      })
    );
  }

  register(newUser): Promise<any> {
    return this.http.post(this.apiAuthRegister, newUser, httpOptions).toPromise();
  }

  logOut(): void {
    console.log('logout');
    this.cookieService.deleteAll('/');
    this.router.navigate(['/']);
  }

  myWishlist(): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ Authorization: this.cookieService.get('token') }) };
    return this.http.get(this.apiWishlist, httpOptions);
  }

  myWishlistIds(): Observable<any> {
    const httpOptions = { headers: new HttpHeaders({ Authorization: this.cookieService.get('token') }) };
    return this.http.get(this.apiWishlist + '/ids', httpOptions);
  }

  addToWishlist(courseId: number): Promise<any> {
    const httpOptions = { headers: new HttpHeaders({ Authorization: this.cookieService.get('token') }) };
    return this.http.post(this.apiWishlist, { course_id: courseId }, httpOptions).toPromise();
  }

  removeFromWishlist(courseId: number): Promise<any> {
    const httpOptions = { headers: new HttpHeaders({ Authorization: this.cookieService.get('token') }) };
    return this.http.post(this.apiUnwishlist, { course_id: courseId }, httpOptions).toPromise();
  }
}
