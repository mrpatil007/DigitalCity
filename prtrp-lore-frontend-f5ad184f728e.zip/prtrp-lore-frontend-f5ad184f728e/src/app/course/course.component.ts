import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { trigger, state, style, animate, transition, keyframes } from '@angular/animations';

import { SearchService } from '../search.service';
import { CompareService } from '../compare.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css'],
  animations: [
    trigger('compareVisible', [
      state(
        'false',
        style({
          backgroundColor: '#eee',
          transform: 'scale(0)'
        })
      ),
      state(
        'true',
        style({
          backgroundColor: '#cfd8dc',
          transform: 'scale(1)'
        })
      ),
      transition('false => true', [
        animate(
          300,
          keyframes([
            style({ opacity: 0, transform: 'translateX(-100%)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(15px)', offset: 0.3 }),
            style({ opacity: 1, transform: 'translateX(0)', offset: 1.0 })
          ])
        )
      ]),
      transition('true => false', [
        animate(
          300,
          keyframes([
            style({ opacity: 1, transform: 'translateX(0)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(-15px)', offset: 0.7 }),
            style({ opacity: 0, transform: 'translateX(100%)', offset: 1.0 })
          ])
        )
      ])
    ])
  ]
})
export class CourseComponent implements OnInit {
  courseId: number;
  courseDetails: any = false;
  compareItems: number = 0;
  compareIds: Array<any> = [];

  constructor(private route: ActivatedRoute, private router: Router, private searchService: SearchService, private compareService: CompareService) {
    this.route.params.subscribe(params => {
      this.courseId = params.id;
      if (this.courseId) {
        this.searchService.getCourseDetails(this.courseId).subscribe(response => {
          if (response.courses && response.courses.length) {
            this.courseDetails = response.courses.pop();
          }
        });
      } else {
        this.router.navigate(['/']);
      }
    });
  }

  addToCompare(id: number) {
    // console.log('addToCompare: ', id);
    if (this.compareService.addToCompare(id)) {
      this.compareIds.push(id);
      this.compareItems = this.compareIds.length;
    } else {
      if (this.compareItems >= 3) {
        alert('Already added 3 courses to compare');
      }
    }
  }

  removeFromCompare(id: string) {
    this.compareService.removeFromCompare(id);
    this.compareIds = this.compareService.getCompareCourses();
    this.compareItems = this.compareIds.length;
  }

  ngOnInit() {
    this.compareIds = this.compareService.getCompareCourses();
    this.compareItems = this.compareIds.length;
  }
}
