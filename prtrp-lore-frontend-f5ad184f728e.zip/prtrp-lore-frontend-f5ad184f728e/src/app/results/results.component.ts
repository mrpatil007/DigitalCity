import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { trigger, state, style, animate, transition, keyframes, group } from '@angular/animations';

import { Observable } from 'rxjs/Observable';
import { ISubscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

import { SearchService } from '../search.service';
import { CompareService } from '../compare.service';
import { AuthService } from '../auth.service';
import { FlashMessagesService } from 'ngx-flash-messages';

import * as $ from 'jquery';
import 'jquery-ui/ui/widgets/slider';

const flashMessageTimeout = 1500;

@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.css'],
  animations: [
    trigger('compareVisible', [
      state(
        'false',
        style({
          backgroundColor: '#eee',
          transform: 'scale(0)'
        })
      ),
      state(
        'true',
        style({
          backgroundColor: '#cfd8dc',
          transform: 'scale(1)'
        })
      ),
      transition('false => true', [
        animate(
          300,
          keyframes([
            style({ opacity: 0, transform: 'translateX(-100%)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(15px)', offset: 0.3 }),
            style({ opacity: 1, transform: 'translateX(0)', offset: 1.0 })
          ])
        )
      ]),
      transition('true => false', [
        animate(
          300,
          keyframes([
            style({ opacity: 1, transform: 'translateX(0)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(-15px)', offset: 0.7 }),
            style({ opacity: 0, transform: 'translateX(100%)', offset: 1.0 })
          ])
        )
      ])
    ]),
    trigger('flyInOut', [
      state('in', style({ transform: 'translateX(0)' })),
      transition('void => *', [
        animate(
          500,
          keyframes([
            style({ opacity: 0, transform: 'translateX(-100%)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(15px)', offset: 0.3 }),
            style({ opacity: 1, transform: 'translateX(0)', offset: 1.0 })
          ])
        )
      ]),
      transition('* => void', [
        animate(
          500,
          keyframes([
            style({ opacity: 1, transform: 'translateX(0)', offset: 0 }),
            style({ opacity: 1, transform: 'translateX(-15px)', offset: 0.7 }),
            style({ opacity: 0, transform: 'translateX(100%)', offset: 1.0 })
          ])
        )
      ])
    ])
  ]
})
export class ResultsComponent implements OnInit, OnDestroy {
  loadPriceSlider = false;
  searchText: string;
  searchTerm: string;
  searchMeta: any;
  searchResults: Array<any>;
  searchFilters: Array<any>;
  loadMore = false;
  currentPage: number;
  totalPages: number;
  criteria: Object = {};
  minPrice = 0;
  maxPrice = 0;
  sliderMinPrice = 0;
  sliderMaxPrice = 0;
  gridLayout = true;
  compareItems = 0;
  compareIds: Array<any> = [];
  activeFilters: Array<{ key: string; value: string }> = [];
  wishlist: Array<number> = [];
  isLoggedIn = false;

  private sliderSubject = new Subject<any>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private searchService: SearchService,
    private compareService: CompareService,
    private authService: AuthService,
    private flashMessagesService: FlashMessagesService
  ) {
    this.route.params.subscribe(params => {
      this.searchText = params.text;
      this.searchTerm = decodeURI(this.searchText);
      if (this.searchText) {
        this.searchService.getSearchResults(this.searchText).subscribe(response => {
          this.handleResults(response, true);
        });
      } else {
        this.router.navigate(['/']);
      }
    });
  }

  loginSuccess() {
    this.isLoggedIn = true;
  }

  logoutSuccess() {
    this.isLoggedIn = false;
  }

  toggleView(view) {
    if (view === 'grid') {
      this.gridLayout = false;
    } else {
      this.gridLayout = true;
    }
  }

  addToCompare(id: number) {
    if (this.compareService.addToCompare(id)) {
      this.flashMessagesService.show('Course Added to Compare', {
        classes: ['alert', 'alert-success'],
        timeout: flashMessageTimeout
      });
      this.compareIds.push(id);
      this.compareItems = this.compareIds.length;
    } else {
      if (this.compareItems >= 3) {
        this.flashMessagesService.show('Already added 3 courses to compare', {
          classes: ['alert', 'alert-danger'],
          timeout: flashMessageTimeout
        });
      }
    }
  }

  removeFromCompare(id: string) {
    this.flashMessagesService.show('Course Removed from Compare', {
      classes: ['alert', 'alert-danger'],
      timeout: flashMessageTimeout
    });
    this.compareService.removeFromCompare(id);
    this.compareIds = this.compareService.getCompareCourses();
    this.compareItems = this.compareIds.length;
  }

  addToWishlist(courseId: number) {
    this.flashMessagesService.show('Course Added to Wishlist', {
      classes: ['alert', 'alert-success'],
      timeout: flashMessageTimeout
    });

    this.wishlist.push(courseId);
    this.authService.addToWishlist(courseId).then(results => {});
  }

  removeFromWishlist(courseId: number) {
    this.flashMessagesService.show('Course Removed from Wishlist', {
      classes: ['alert', 'alert-danger'],
      timeout: flashMessageTimeout
    });

    this.wishlist = this.wishlist.filter(x => x !== courseId);
    this.authService.removeFromWishlist(courseId).then(results => {});
  }

  resetPriceSlider() {
    this.loadPriceSlider = true;
    if (this.loadPriceSlider) {
      ($('#slider-range') as any).slider('destroy');
      ($('#slider-range-mobile') as any).slider('destroy');

      ($('#slider-range') as any).slider({
        range: true,
        min: this.minPrice,
        max: this.maxPrice,
        values: [this.minPrice, this.maxPrice],
        slide: (event, slider) => {
          this.sliderMinPrice = slider.values[0];
          this.sliderMaxPrice = slider.values[1];
          this.priceSlider(slider.values[0], slider.values[1]);
          this.buildActiveFilters();
        }
      });

      ($('#slider-range-mobile') as any).slider({
        range: true,
        min: this.minPrice,
        max: this.maxPrice,
        values: [this.minPrice, this.maxPrice],
        slide: (event, slider) => {
          this.sliderMinPrice = slider.values[0];
          this.sliderMaxPrice = slider.values[1];
          this.priceSlider(slider.values[0], slider.values[1]);
          this.buildActiveFilters();
        }
      });

      this.loadPriceSlider = false;
    }
  }

  clearAllFilters() {
    this.criteria = {};
    this.activeFilters = [];
    this.sliderMinPrice = this.minPrice;
    this.sliderMaxPrice = this.maxPrice;
    this.resetPriceSlider();

    this.searchService.getSearchResults(this.searchText).subscribe(response => {
      this.handleResults(response);
    });
  }

  private handleResults(results, initialRequest = false) {
    // console.log('handleResults', results);
    this.searchMeta = results.meta;
    this.searchResults = results.results;
    if (initialRequest) {
      this.loadPriceSlider = true;
      this.searchFilters = results.facets;
      this.criteria = {};
      this.minPrice = parseInt(results.price.min);
      this.maxPrice = parseInt(results.price.max);
      this.sliderMinPrice = this.minPrice;
      this.sliderMaxPrice = parseInt(results.price.max);
    }
    this.currentPage = this.searchMeta.page;
    this.totalPages = this.searchMeta.total_pages;

    if (this.searchMeta.page < this.searchMeta.total_pages) {
      this.loadMore = true;
    } else {
      this.loadMore = false;
    }
  }

  loadMoreResults() {
    this.searchService.getSearchResults(this.searchText, this.currentPage + 1, this.criteria, this.sliderMinPrice, this.sliderMaxPrice, this.minPrice, this.maxPrice).subscribe(response => {
      this.searchMeta = response.meta;

      if (response.results && response.results.length) {
        response.results.forEach(result => this.searchResults.push(result));
      }
      this.currentPage = this.searchMeta.page;
      this.totalPages = this.searchMeta.total_pages;

      if (this.searchMeta.page < this.searchMeta.total_pages) {
        this.loadMore = true;
      } else {
        this.loadMore = false;
      }
    });
  }

  buildActiveFilters() {
    this.activeFilters = [];
    for (const key in this.criteria) {
      for (const value in this.criteria[key]) {
        this.activeFilters.push({ key: key, value: this.criteria[key][value] });
      }
    }

    if (this.sliderMinPrice !== this.minPrice) {
      this.activeFilters.push({ key: 'minPrice', value: 'Min Price: ' + this.sliderMinPrice });
    }

    if (this.sliderMaxPrice !== this.maxPrice) {
      this.activeFilters.push({ key: 'maxPrice', value: 'Max Price: ' + this.sliderMaxPrice });
    }
  }

  resetPriceFilters(filter, value) {
    // console.log('resetPriceFilters: ', filter, value);

    if (['minPrice', 'maxPrice'].indexOf(filter) !== -1) {
      if (filter === 'minPrice') {
        this.sliderMinPrice = this.minPrice;
        this.activeFilters = this.activeFilters.filter(activeFilter => activeFilter.key !== 'minPrice');
      } else {
        this.sliderMaxPrice = this.maxPrice;
        this.activeFilters = this.activeFilters.filter(activeFilter => activeFilter.key !== 'maxPrice');
      }
      this.resetPriceSlider();
      this.searchService.getSearchResults(this.searchText, 1, this.criteria, this.sliderMinPrice, this.sliderMaxPrice, this.minPrice, this.maxPrice).subscribe(response => {
        this.handleResults(response);
      });
    }
  }

  applyFilters(event, filter, value) {
    // console.log('applyFilters: ', filter, value);
    if (!this.criteria[filter]) {
      this.criteria[filter] = [];
    }

    if (event.target.checked) {
      if (this.criteria[filter].indexOf(value) === -1) {
        this.criteria[filter].push(value);
      }
    } else {
      if (this.criteria[filter].indexOf(value) !== -1) {
        this.criteria[filter].splice(this.criteria[filter].indexOf(value), 1);
      }
    }

    this.buildActiveFilters();
    this.searchService.getSearchResults(this.searchText, 1, this.criteria, this.sliderMinPrice, this.sliderMaxPrice, this.minPrice, this.maxPrice).subscribe(response => {
      this.handleResults(response);
    });
  }

  priceSlider(minPrice: number, maxPrice: number) {
    this.sliderSubject.next({ minPrice, maxPrice });
  }

  ngOnInit() {
    this.compareIds = this.compareService.getCompareCourses();
    this.compareItems = this.compareIds.length;
    this.isLoggedIn = this.authService.isValid();

    this.authService.myWishlistIds().subscribe(results => {
      if (results.length) {
        this.wishlist = results;
      }
    });

    this.sliderSubject.pipe(debounceTime(500), distinctUntilChanged()).subscribe(priceRange => {
      this.searchService.getSearchResults(this.searchText, 1, this.criteria, priceRange.minPrice, priceRange.maxPrice, this.minPrice, this.maxPrice).subscribe(response => {
        this.handleResults(response);
      });
    });

    ($(window) as any).scroll(() => {
      if ($(window).scrollTop() + $(window).height() === $(document).height()) {
        console.log('document.end');
        if (this.loadMore) {
          this.loadMoreResults();
        }

        ($('#comparebutton') as any).css('bottom', '40px');
      } else {
        ($('#comparebutton') as any).css('bottom', 0);
      }
    });
  }

  ngAfterViewChecked() {
    if (this.loadPriceSlider) {
      ($('#slider-range') as any).slider({
        range: true,
        min: this.minPrice,
        max: this.maxPrice,
        values: [this.minPrice, this.maxPrice],
        slide: (event, slider) => {
          this.sliderMinPrice = slider.values[0];
          this.sliderMaxPrice = slider.values[1];
          this.priceSlider(slider.values[0], slider.values[1]);
          this.buildActiveFilters();
        }
      });

      ($('#slider-range-mobile') as any).slider({
        range: true,
        min: this.minPrice,
        max: this.maxPrice,
        values: [this.minPrice, this.maxPrice],
        slide: (event, slider) => {
          this.sliderMinPrice = slider.values[0];
          this.sliderMaxPrice = slider.values[1];
          this.priceSlider(slider.values[0], slider.values[1]);
          this.buildActiveFilters();
        }
      });

      this.loadPriceSlider = false;
    }
  }

  ngOnDestroy() {
    ($('#slider-range') as any).slider('destroy');
    ($('#slider-range-mobile') as any).slider('destroy');
  }
}
