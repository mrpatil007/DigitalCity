import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SearchService } from '../search.service';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import * as $ from 'jquery';
import 'jquery-ui/ui/widgets/autocomplete';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit, OnDestroy {
  private autoSuggest;
  private autoSuggestSubject = new Subject<any>();

  @Input() homePage: boolean = true;

  constructor(private router: Router, private searchService: SearchService) {}

  search(searchText) {
    if (searchText) {
      ($('#search') as any).autocomplete('close');
      this.router.navigate(['/results/' + encodeURIComponent(searchText)]);
    }
  }

  ngOnInit() {
    ($('#search') as any).autocomplete({
      minLength: 3,
      delay: 250,
      source: (request, response) => {
        const term = request.term;
        this.autoSuggestSubject.next({ term, response });
      }
    });

    this.autoSuggestSubject.subscribe(autoComplete => {
      this.searchService.sendSearchText(autoComplete.term);
      this.searchService.getSuggestions().then(results => {
        const autoSuggestions = results.suggestions.map(suggestion => {
          return suggestion.name;
        });
        autoComplete.response(autoSuggestions);
      });
    });
  }

  ngOnDestroy() {
    ($('#search') as any).autocomplete('destroy');
    this.searchService.socketDisconnect();
  }
}
