import { Component, OnInit } from '@angular/core';

import { SearchService } from '../search.service';
import { CompareService } from '../compare.service';
import { FlashMessagesService } from 'ngx-flash-messages';

const flashMessageTimeout = 1500;

@Component({
  selector: 'app-compare',
  templateUrl: './compare.component.html',
  styleUrls: ['./compare.component.css']
})
export class CompareComponent implements OnInit {
  compareCourses: Array<string> = [];
  courses: Array<any> = [];

  constructor(private searchService: SearchService, private compareService: CompareService, private flashMessagesService: FlashMessagesService) {}

  loadCompareCourses() {
    this.compareCourses = this.compareService.getCompareCourses();
    if (this.compareCourses.length) {
      this.searchService.getCourseDetails(this.compareCourses.join('|')).subscribe(response => {
        if (response.courses && response.courses.length) {
          this.courses = response.courses;
        } else {
        }
      });
    } else {
      this.courses = [];
      this.flashMessagesService.show('No course is selected for comparison.', {
        classes: ['alert', 'alert-danger'],
        timeout: flashMessageTimeout
      });

      setTimeout(function() {
        console.log('go back');
        window.history.back();
      }, flashMessageTimeout);
    }
  }

  removeFromCompare(courseId) {
    this.flashMessagesService.show('Course Removed from Compare', {
      classes: ['alert', 'alert-danger'],
      timeout: flashMessageTimeout
    });

    this.compareService.removeFromCompare(courseId);
    this.loadCompareCourses();
  }

  ngOnInit() {
    this.loadCompareCourses();
  }
}
