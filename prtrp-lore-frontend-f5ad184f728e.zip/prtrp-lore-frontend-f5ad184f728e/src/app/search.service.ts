import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';

import * as io from 'socket.io-client';

@Injectable()
export class SearchService {
  private socket;
  private searchApiEndpoint = environment.apiHost + '/api/search';
  private courseDetailsEndpoint = environment.apiHost + '/api/courses';

  constructor(private http: HttpClient, private authService: AuthService) {
    this.socket = io(environment.apiHost, { transports: ['websocket'] });
  }

  sendSearchText(text: String): void {
    this.socket.emit('suggestions', text);
  }

  getSuggestions(): Promise<any> {
    return new Promise(resolve => {
      this.socket.on('suggestions', suggestions => {
        resolve(suggestions);
      });
    });
  }

  getSearchResults(text: String, page: number = 1, filters: Object = {}, minPrice: number = 0, maxPrice: number = 0, priceStart: number = 0, priceLimit: number = 0): Observable<any> {
    const userId = this.authService.getUser().id;
    let queryString = '';
    if (Object.keys(filters).length) {
      queryString = '?';
      for (const key in filters) {
        if (filters.hasOwnProperty(key) && filters[key].length) {
          queryString += `${key}=${filters[key].join('|')}&`;
        }
      }
      queryString = queryString.slice(0, -1);
    }

    if (minPrice > 0 && minPrice != priceStart) {
      queryString += queryString.indexOf('?') === -1 ? `?minPrice=${minPrice}` : `&minPrice=${minPrice}`;
    }

    if (maxPrice > 0 && maxPrice !== priceLimit) {
      queryString += queryString.indexOf('?') === -1 ? `?maxPrice=${maxPrice}` : `&maxPrice=${maxPrice}`;
    }

    if (userId) {
      queryString += queryString.indexOf('?') === -1 ? `?userId=${userId}` : `&userId=${userId}`;
    }

    const searchApi = `${this.searchApiEndpoint}/${text}/${page}${queryString}`;
    console.log('searchApi:', filters, searchApi);

    return this.http.get(searchApi).pipe(catchError(this.handleError('getSearchResults', [])));
  }

  getCourseDetails(courseId): Observable<any> {
    const courseDetailsApi = `${this.courseDetailsEndpoint}/${courseId}`;
    // console.log('courseDetailsApi:', courseDetailsApi);

    return this.http.get(courseDetailsApi).pipe(catchError(this.handleError('getCourseDetails', [])));
  }

  socketDisconnect(): void {
    this.socket.removeAllListeners();
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
