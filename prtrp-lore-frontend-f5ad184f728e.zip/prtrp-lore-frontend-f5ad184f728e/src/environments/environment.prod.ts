export const environment = {
  production: true,
  apiHost: ''
};
