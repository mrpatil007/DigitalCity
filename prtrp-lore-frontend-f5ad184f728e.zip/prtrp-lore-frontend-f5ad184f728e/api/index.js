const express = require('express');
const router = express.Router();

const auth = require('./auth');
// const mailer = require('./mailer');
const search = require('./search');

// SEARCH API ROUTES
router.get('/suggestions/:text', search.getSuggestions);
router.get('/search/:text/:page?', search.getResults);
router.get('/courses/:id', search.getCoursesById);

// AUTH API ROUTES
router.post('/auth/login', auth.login);
router.post('/auth/register', auth.register);
router.post('/wishlist', auth.addWishlist);
router.get('/wishlist', auth.getWishlist);
router.get('/wishlist/ids', auth.getWishlistIds);
router.post('/unwishlist', auth.removeWishlist);
// router.post('/reset-password', auth.resetPassword);
// router.post('/change-password', auth.canAccess, auth.changePassword);

// // MAILER API ROUTES
// router.post('/send-reset-password-email', mailer.sendResetPasswordEmail);
// router.post('/send-notification-email', auth.canAccess, mailer.sendNotificationEmail);

module.exports = router;
