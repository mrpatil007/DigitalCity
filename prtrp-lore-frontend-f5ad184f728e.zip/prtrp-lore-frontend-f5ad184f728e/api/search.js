const config = require('./config');
const fetch = require('node-fetch');

const SEARCH_API_ENDPOINT = config.api.endpoint + '/search/';
const SUGGESTIONS_API_ENDPOINT = config.api.endpoint + '/suggestions/';
const COURSES_DETAILS_API_ENDPOINT = config.api.endpoint + '/courses/';

function getResults(request, response, next) {
  const searchText = request.params.text;
  const page = request.params.page ? request.params.page : 1;

  let queryParams = [];
  if (request.query.provider) {
    queryParams.push(`provider=${request.query.provider}`);
  }
  if (request.query.minPrice) {
    queryParams.push(`minPrice=${request.query.minPrice}`);
  }
  if (request.query.maxPrice) {
    queryParams.push(`maxPrice=${request.query.maxPrice}`);
  }
  if (request.query.duration) {
    queryParams.push(`duration=${request.query.duration}`);
  }
  if (request.query.level) {
    queryParams.push(`level=${request.query.level}`);
  }
  if (request.query.userId) {
    queryParams.push(`userId=${request.query.userId}`);
  }
  if (request.query.free) {
    queryParams.push(`free=${request.query.free}`);
  }

  if (queryParams.length) {
    queryParams = `?${queryParams.join('&')}`;
  } else {
    queryParams = '';
  }

  const searchAPI = SEARCH_API_ENDPOINT + searchText + '/' + page + queryParams;

  fetch(searchAPI)
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function getSuggestions(request, response, next) {
  const searchText = request.params.text;
  const suggestionsAPI = SUGGESTIONS_API_ENDPOINT + searchText;

  fetch(suggestionsAPI)
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function getCoursesById(request, response, next) {
  const courseIds = request.params.id;
  const coursesDetailsAPI = COURSES_DETAILS_API_ENDPOINT + courseIds;

  fetch(coursesDetailsAPI)
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

module.exports = {
  getResults: getResults,
  getSuggestions: getSuggestions,
  getCoursesById: getCoursesById
};
