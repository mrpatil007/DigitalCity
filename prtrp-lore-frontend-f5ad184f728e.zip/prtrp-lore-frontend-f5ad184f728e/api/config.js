module.exports = {
  api: {
    endpoint: process.env.API_URL ? process.env.API_URL : 'http://localhost/lore/api'
  },
  jwt: {
    secret: 'Y2ZLVw6MSX'
  }
};
