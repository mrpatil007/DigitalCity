const config = require('./config');
const fetch = require('node-fetch');
const urlSearchParams = require('url').URLSearchParams;

const LOGIN_API_ENDPOINT = config.api.endpoint + '/auth/login';
const REGISTER_API_ENDPOINT = config.api.endpoint + '/auth/register';
const WISHLIST_API_ENDPOINT = config.api.endpoint + '/wishlist';
const UNWISHLIST_API_ENDPOINT = config.api.endpoint + '/unwishlist';

function login(request, response, next) {
  const params = new urlSearchParams(request.body);
  fetch(LOGIN_API_ENDPOINT, { method: 'POST', body: params })
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function register(request, response, next) {
  const params = new urlSearchParams(request.body);
  fetch(REGISTER_API_ENDPOINT, { method: 'POST', body: params })
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function addWishlist(request, response, next) {
  const jwtToken = request.headers.authorization;
  const params = new urlSearchParams(request.body);

  fetch(WISHLIST_API_ENDPOINT, {
    method: 'POST',
    body: params,
    headers: {
      Authorization: jwtToken
    }
  })
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function getWishlist(request, response, next) {
  const jwtToken = request.headers.authorization;

  fetch(WISHLIST_API_ENDPOINT, {
    method: 'GET',
    headers: {
      Authorization: jwtToken
    }
  })
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function getWishlistIds(request, response, next) {
  const jwtToken = request.headers.authorization;

  fetch(WISHLIST_API_ENDPOINT + '/ids', {
    method: 'GET',
    headers: {
      Authorization: jwtToken
    }
  })
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

function removeWishlist(request, response, next) {
  const jwtToken = request.headers.authorization;
  const params = new urlSearchParams(request.body);

  fetch(UNWISHLIST_API_ENDPOINT, {
    method: 'POST',
    body: params,
    headers: {
      Authorization: jwtToken
    }
  })
    .then(results => results.json())
    .then(json => response.status(200).json(json))
    .catch(error => response.status(500).json(error));
}

/////////////
// Exports
/////////////

module.exports = {
  login: login,
  register: register,
  addWishlist: addWishlist,
  removeWishlist: removeWishlist,
  getWishlist: getWishlist,
  getWishlistIds: getWishlistIds
};
