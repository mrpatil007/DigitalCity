const nodemailer = require('nodemailer');
const sgTransport = require('nodemailer-sendgrid-transport');
const Email = require('email-templates');
const path = require('path');
const { config } = require('./config');
const { forgotPassword } = require('./auth');

const sgOptions = {
  auth: {
    api_key: config.email.SENDGRID_API_KEY
  }
};
const transporter = nodemailer.createTransport(sgTransport(sgOptions));

const email = new Email({
  message: {
    from: config.email.NOREPLY_EMAIL
  },
  views: {
    root: path.join(__dirname, 'emails'),
    options: {
      extension: 'hbs'
    }
  },
  preview: false,
  send: true,
  transport: transporter
});

function sendNotificationEmail(req, res, next) {
  const notification = req.body;
  email
    .send({
      template: 'notification',
      message: {
        to: notification.email
      },
      locals: {
        notification,
        siteUrl: config.site.url
      }
    })
    .then(function(result) {
      res.status(200).json({ sent: true });
    })
    .catch(function(error) {
      res.status(200).json({ sent: false });
    });
}

function sendResetPasswordEmail(req, res, next) {
  const userEmail = req.body.email;

  forgotPassword(userEmail)
    .then(results => {
      if (results.length == 0) {
        res.status(200).json({ error: 'email not found' });
      } else {
        const name = results.first_name;
        const token = results.token;
        email
          .send({
            template: 'password-reset',
            message: {
              to: userEmail
            },
            locals: {
              name,
              token,
              siteUrl: config.site.url
            }
          })
          .then(function(result) {
            res.status(200).json({ sent: true });
          })
          .catch(function(error) {
            res.status(200).json({ sent: false });
          });
      }
    })
    .catch(error => {
      res.status(200).json(error);
    });
}

/////////////
// Exports
/////////////

module.exports = {
  sendNotificationEmail: sendNotificationEmail,
  sendResetPasswordEmail: sendResetPasswordEmail
};
